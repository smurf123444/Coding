Use the  delete-session.php  file to remove all products from the cart
Note that the functions.php file has functions that can be used by multiple scripts